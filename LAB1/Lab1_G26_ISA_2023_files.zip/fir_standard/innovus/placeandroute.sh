# source synopsys stuff
source /eda/scripts/init_design_vision > /dev/null

# launch the syntesys script
dc_shell-xg-t -f placeandroute.tcl