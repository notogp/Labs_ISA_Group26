################################
The functions fir1 and butter are part 
of the signal-processing toolbox. If you 
use Matlab be sure to have the signal-processing 
toolbox installed. If you use Octave you have 
to download and install the signal-processing
toolbox as well. In case this zip contains 
the functions (taken from Octave signal-processing 
toolbox) for using fir1 and butter.
#################################
